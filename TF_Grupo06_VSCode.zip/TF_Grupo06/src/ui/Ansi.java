package ui;

/** Códigos de escape ANSI para colorear la consola. */
public final class Ansi {

    public static final String RESET = "\u001B[0m";
    public static final String AZUL = "\u001B[34m";
    public static final String VERDE = "\u001B[32m";
    public static final String ROJO = "\u001B[31m";
    public static final String AMARILLO = "\u001B[33m";
    public static final String CIAN = "\u001B[36m";

    private Ansi() {
    }
}
